<?php 
session_start();
if(!isset($_SESSION["sUsername"]))
    header("location:login.php");


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

        <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Nicholas Hedges</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.html" target="_self">Home<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Teacher Details</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Web Design Course Area Start -->
<section class="section-full teacher-details">
    <div class="container">
        <div class="row">
            <div class="web-course">
                <div class="col-md-8 col-xs-12">
                    <div class="left-web-course">
                        <div class="teacher-top flex">
                            <div class="teacher-img">
                                <img src="img/teacher/c1.png" alt="" class="img-responsive">
                            </div>
                            <div class="teacher-top-content">
                                <h2>Nicholas Hedges</h2>
                                <p>Lecturer,  Faculty of Computer Science</p>
                               
                            </div>
                        </div>
                        <div class="tab-menu mt-20">
                            <ul id="tabs-swipe-demo" class="tabs course-tab">
                                <li class="tab"><a href="#about">About Me</a></li>
                                <li class="tab"><a href="#course">My Subjects</a></li>
                            </ul>
                        </div>
                        <div id="about" class="about mt-30">
                            
                                
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est lut persp aborum.</p>
                                
                                
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est lut persp aborum.</p>
                                
                            
                                    <p >Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                        <div id="course" class="course mt-30 course-outline text-center">
                            <ul class="flex space-between no-flex-xs">
                                <li><img src="img/teacher/a1.jpg" alt=""></li>
                                <li class="head">Web Development</li>
                                <li><a href="coursedet.php" target="_self">View Course Details</a></li>
                            </ul>
                            <ul class="flex space-between no-flex-xs">
                                <li><img src="img/teacher/a1.jpg" alt=""></li>
                                <li class="head">Web Development</li>
                                <li><a href="coursedet.php" target="_self">View Course Details</a></li>
                            </ul>
                            <ul class="flex space-between no-flex-xs">
                                <li><img src="img/teacher/a1.jpg" alt=""></li>
                                <li class="head">Web Development</li>
                                <li><a href="coursedet.php" target="_self">View Course Details</a></li>
                            </ul>
                            <ul class="flex space-between no-flex-xs">
                                <li><img src="img/teacher/a1.jpg" alt=""></li>
                                <li class="head">Web Development</li>
                                <li><a href="coursedet.php" target="_self">View Course Details</a></li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                    <div class="right-web-course">
                        <div class="single-info flex space-between">
                            <h4><span class="et-line icon-envelope"></span>Email</h4>
                            <h4>abc@xyz.com</h4>
                        </div>
                        <div class="single-info flex space-between">
                            <h4><span class="et-line icon-megaphone"></span>Phone</h4>
                            <h4>+91 0123456789</h4>
                        </div>
                    </div>
                
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Web Design Course End -->
</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>

</html>
<?php 
session_start();
if(!isset($_SESSION["sUsername"]))
    header("location:login.php");


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

        <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">ELP</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.html" target="_self">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">About ELP</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Welcome Area Start -->
<section id="about" class="section-full">
    <div class="container">
        <div class="welcome-1">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-100">
                        <h2 class="first-title">Welcome to E-Learning Platform</h2>
                        <p style="font-size: large;">Lorem ipsum dolor sit amet, consectetur adippisicing
                        elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="welcome-body">
                    <div class="col-sm-4 col-xs-12">
                        <div class="welcome-stat">
                            <div class="col-sm-6 col-xs-3">
                                <div class="single-stat">
                                    <span class="et-line icon-ribbon"></span>
                                    <h2 class="mt-25 mb-5">99%</h2>
                                    <p>Graduates</p>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-3">
                                <div class="single-stat">
                                    <span class="et-line icon-briefcase"></span>
                                    <h2 class="mt-25 mb-5">99%</h2>
                                    <p>Graduates</p>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-3">
                                <div class="single-stat">
                                    <span class="et-line icon-bargraph"></span>
                                    <h2 class="mt-25 mb-5">99%</h2>
                                    <p>Graduates</p>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-3">
                                <div class="single-stat">
                                    <span class="et-line icon-profile-male"></span>
                                    <h2 class="mt-25 mb-5">99%</h2>
                                    <p>Graduates</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-xs-12">
                        <div class="welcome-slider">
                            <div class="slider-box">
                                <div class="slider-corner1">
                                    <div class="mini-corner1"></div>
                                    <div class="mini-corner2"></div>
                                </div>
                                <div class="slider-corner2">
                                    <div class="mini-corner1"></div>
                                    <div class="mini-corner2"></div>
                                </div>
                                <div class="wel-slider">
                                    <div class="item" style="background-image: url(img/slider/mini-slider.jpg);"></div>
                                    <div class="item" style="background-image: url(img/slider/mini-slider.jpg);"></div>
                                    <div class="item" style="background-image: url(img/slider/mini-slider.jpg);"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Welcome Area End -->
<!-- Teacher Area Start -->
<section id="chose-teachers" class="bg-gray section-full expert-trainer our-teacher">
    <div class="container">
        <div class="chose-course">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-100">
                        <h2 class="first-title">Expert Trainers</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adippisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="total-trainer">
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="single-trainer">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/1.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.html" target="_self">Austin Collins</a></h4>
                                        <p class="mt-10 mb-1">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.html" target="_self" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="single-trainer">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/2.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.html" target="_self">Karma Reddy</a></h4>
                                        <p class="mt-10 mb-15">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.html" target="_self" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="single-trainer">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/3.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.html" target="_self">Victor Valdez</a></h4>
                                        <p class="mt-10 mb-15">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.html" target="_self" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="single-trainer">
                                <div class="col-sm-6">
                                    <div class="teacher-img" style="background-image: url(img/teacher/4.jpg);">
                                        <div class="teacher-profile">
                                            <div class="social-link">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-dribbble"></i></a>
                                                <a href="#"><i class="fa fa-behance"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="trainer-info">
                                        <h4><a href="29-teacher-details.html" target="_self">Solomon Allot</a></h4>
                                        <p class="mt-10 mb-15">Lorem ipsum dolor sit ametco nsect etur adipisicing elit, sed do eiusmodte mpor incididunt ut labore et dolore magna aliqua ut enim.</p>
                                        <p><a href="29-teacher-details.html" target="_self" class="read">Read More<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- / #Teacher Area End  -->
<!-- Testimonial Area Start -->
<section class="testimonial-1">
    <div class="container">
        <div class="row no-margin">
            <div class="col-sm-offset-1 col-sm-offset-11 col-xs-12">
                <div class="testimonial-border">
                    <div class="test-img hidden-xs hidden-sm">
                        <img src="img/testimonial/t1.png" class="img-responsive" alt="">
                    </div>
                    <div class="row">
                        <div class="col-md-offset-6 col-md-6 col-sm-12">
                            <div class="testimonial-content">
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                    <h6>Lara Croft Johnson</h6>
                                    <span>Adobe Indesign</span>
                                </div>
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                    <h6>Lara Croft Johnson</h6>
                                    <span>Adobe Indesign</span>
                                </div>
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                    <h6>Lara Croft Johnson</h6>
                                    <span>Adobe Indesign</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</main>

<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
       
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>


</html>
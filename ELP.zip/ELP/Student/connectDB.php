<?php


	// $conn = new mysqli("sql311.epizy.com","epiz_31131670","cu64zWANZcr","epiz_31131670_elp");

		$conn = new mysqli("localhost","root","","elp");

	
 
 ?>
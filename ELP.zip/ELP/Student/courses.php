<?php 
    session_start();
    if(!isset($_SESSION["sUsername"]))
        header("location:login.php");
        $sdept=$_SESSION["sdept"];

    include 'connectDB.php';
    $res=$conn->query("select * from subject where subdept='$sdept'");
    
?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
       <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider" class="">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">All Subjects</h2>
            <ul class="page-title-btn">
                <li><a href="#" target="_self">Home<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">All Subjects</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Regular Course Area Start -->
<section class="section-full course-grid1">
    <div class="container">
        <div class="row">
            <div class="popular-course-body">
                <!-- <div class="col-sm-4">
                    <div class="single-popular">
                        <img src="https://www.ajayonlinestall.com/wp-content/uploads/2022/01/9789385138072.jpg" class="img-responsive" alt="">
                        <div class="grid-course">
                            <div class="popular-course-content p-40">
                                <h3 style="margin-bottom: 30px;"><a href="coursedet.php" target="_self" style="line-height: 1.2">Android Application Development</a></h3>
                                
                                <p>Basics of android app development UI/UX design, Event Handling, Database Management</p> 
                                <a href="coursedet.php" target="_self" class="learn" >Visit Now  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                            </div>
                            
                        </div>
                    </div>
                </div> -->
                <?php 
                while ($row=$res->fetch_object()) 
                {
                 ?>
                <div class="col-sm-4">
                    <div class="single-popular">
                        <img src="<?php echo $row->subimg_url; ?>" class="img-responsive" alt="">
                        <div class="grid-course">
                            <div class="popular-course-content p-40">
                                <h3 style="margin-bottom: 30px;"><a href="coursedet.php?subcode=<?php echo $row->subcode; ?>" target="_self" style="line-height: 1.2"><?php echo $row->subname; ?></a></h3>
                                <h4 style="margin-bottom: 15px;">Subject Code: <?php echo $row->subcode; ?></h4>
                                <!-- <p>Basics of android app development UI/UX design, Event Handling, Database Management</p> -->
                                <a href="coursedet.php?subcode=<?php echo $row->subcode; ?>" target="_self" class="learn" >Visit Now  <i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</section>

</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>


</html>
<?php 
session_start();
if(!isset($_SESSION["sUsername"]))
    header("location:login.php");

    $subcode=$_GET["subcode"];
    $sid=$_SESSION["sid"];

    include 'connectDB.php';

    $subres=$conn->query("select * from subject where subcode='$subcode'");
    $subrow=$subres->fetch_object();
    $chres=$conn->query("select * from subchap where subcode='$subcode'");

    if(isset($_POST["submit"]))
    {
        $sugmsg=$_POST["sugmsg"];
        $query="insert into suggestion (sugmsg,sid,subcode) values('$sugmsg','$sid','$subcode')";
        $check=$conn->query($query);
        if ($check) {
            header("location:coursedet.php?subcode=$subcode");   
        }
        else{
            echo "<script>alert('Error Ocurred!')</script>";     
        }
        // echo $sugmsg;
        // echo $sid;
        // echo $subcode;
    }

?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

     <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title"><?php echo $subrow->subname ?></h2>
            <ul class="page-title-btn">
                <li><a href="#" target="_self">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" target="_self">Subject <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Subject Detail</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Web Design Course Area Start -->
<section class="section-full">
    <div class="container">
        <div class="row">
            <div class="web-course">
                <div class="col-md-8 col-xs-12">
                    <div class="left-web-course">
                        <img src="<?php echo $subrow->subimg_url; ?>" alt="" class="img-responsive" style="border: solid 1px grey; margin-left:auto;margin-right: auto; height: 500px;" width="100%"> 
                        <div class="tab-menu mt-20">
                            <ul id="tabs-swipe-demo" class="tabs course-tab">
                                <!-- <li class="tab"><a href="#objectives">Objectives</a></li> -->
                                <!-- <li class="tab"><a href="#eligibility">Eligibility</a></li> -->
                                <li class="tab"><a href="#course-outline">Chapters</a></li>
                                <!-- <li class="tab"><a class="active" href="#comments">Comments</a></li> -->
                            </ul>
                        </div>
                        <!-- <div id="objectives" class="objectives mt-30">
                            <p>Android is an open source and Linux-based operating system for mobile devices such as smartphones and tablet computers. Android was developed by the Open Handset Alliance, led by Google, and other companies. This tutorial will teach you basic Android programming and will also take you through some advance concepts related to Android application development.</p>
                            <p>Android programming is based on Java programming language so if you have basic understanding on Java programming then it will be a fun to learn Android application development.</p>
                        </div> -->
                        
                        <div id="course-outline" class="course-outline mt-30">
                            <!-- <ul class="flex space-between">
                                <li>Chapter 1: Introduction to Android</li>
                                <li><a href="notelist.php">View Details</a></li>
                            </ul> -->
                            <?php while($chrow=$chres->fetch_object()){ ?>
                                <ul class="flex space-between">
                                    <li>Chapter <?php echo $chrow->chnum; ?>: <?php echo $chrow->chname; ?></li>
                                    <li><a href="notelist.php?chnum=<?php echo $chrow->chnum;?>&subcode=<?php echo $subcode ?>">View Details</a></li>
                                </ul>                            
                            <?php } ?>
                        </div>
                       
                            <div class="leave-comment">
                                <h4>Leave a Commnt</h4>
                                <form method="post">
                                    <div class="col-sm-12">
                                        
                                        <p>
                                            <textarea placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" name="sugmsg" id="sugmsg"></textarea>
                                        </p>
                                    </div>
                                    <div class="col-sm-5">
                                        
                                        <p><button class="btn submit-btn" name="submit" type="submit">Submit Comment</button></p>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-xs-12">
                    <div class="right-web-course">
                        <div class="single-info flex space-between">
                            <h4>Subject Name</h4>
                            <h4><a href="#"><?php echo $subrow->subname ?></a></h4>
                        </div>
                      
                        <div class="single-info flex space-between">
                            <h4>Subject Code</h4>
                            <h4><?php echo $subrow->subcode ?></h4>
                        </div>
                       
                        <div class="single-info flex space-between">
                            <h4>Subject Department</h4>
                            <h4><?php echo $subrow->subdept ?></h4>
                        </div>
                       
                        <div class="text-center"><a href="notelist.php?subcode=<?php echo $subcode; ?>"> <button class="btn enroll">Start Learning Now!</button></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>


</html>
<?php 

    session_start();
    include 'connectDB.php';

    $sid=$_SESSION["sid"];

    if(isset($_POST["submit"]))
    {
        $semail=$_POST["semail"];
        $spassword=$_POST["spassword"];

        $query="select * from student where semail='$semail' and spassword='$spassword'";
        $res=$conn->query($query);
        $row=$res->fetch_object();

        if($res->num_rows)
        {
            $nspassword=$_POST["nspassword"];  
            $cnspassword=$_POST["cnspassword"];
            if($nspassword==$cnspassword)
            {
                $query="update student set spassword='$nspassword' where sid='$sid'";
                $check=$conn->query($query);
                if($check)
                    header("location:index1.php");
                else
                    echo "<script>alert('Error Occured!')</script>";
            }
            else{
                    echo "<script>alert('Password and Confirm Password do not match')</script>";    
            }
        }
        else
        {
          echo "<script>alert('Wrong Password')</script>";
        }

    }


 ?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

        <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div>
<main>
<section id="slider" class="slider-section login">
    <div class="slider2">
        <div class="register-bg fullscreen flex flex-middle relative">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="register-content">
                            <h1 class="mb-20">Reset Password</h1>
                            <p style="font-size: 18px;">Incase you do not have login credentials, <br>please contact your H.O.D. or class Coordinator to get one.</p>
                            <!-- <a href="21-login-register.html" class="btn">Don’t have an Account?</a> -->
                        </div>
                    </div>
                    <div class="col-md-offset-1 col-md-5 col-sm-6 col-xs-12">
                        <div class="register-form login-form">
                            <h3>log In</h3>
                            <form method="post">
                                <label>Username or Email Address</label>
                                <p><input type="text"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Username'" placeholder="Username" id="semail" name="semail"></p>
                                <label>Password</label>
                                <p><input type="password"  onfocus="this.placeholder = ''" onblur="this.placeholder = '........'" placeholder="........" id="spassword" name="spassword"></p>
                                <label>New password</label>
                                <p><input type="password"  onfocus="this.placeholder = ''" onblur="this.placeholder = '........'" placeholder="........" id="nspassword" name="nspassword"></p>
                                <label>Confirm new password</label>
                                <p><input type="password"  onfocus="this.placeholder = ''" onblur="this.placeholder = '........'" placeholder="........" id="cnspassword" name="cnspassword"></p>
                                <!-- <div class="check"><input id="one" type="checkbox"><label for="one"><span></span>Keep me logged in</label></div> -->
                                <div><button type="submit" class="btn" name="submit">Log In</button></div>
                                <p class="forgot"><a href="#" onclick="alert('Please Contact your H.O.D or Class Coordinator to get new credentials.')">Forgot Password?</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</main>

        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>

</html>
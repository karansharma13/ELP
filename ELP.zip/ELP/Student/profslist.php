<?php 
session_start();
if(!isset($_SESSION["sUsername"]))
    header("location:login.php");


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

        <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div><main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Teachers List</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.html" target="_self">Home<i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Teachers List</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<section class="section-full teacher">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="event-filter flex">
                    
                    <div class="single-filter col-md-8">
                        <input placeholder="Enter Teacher Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Teacher Name'" type="text" id="teach">
                    </div>
                    <div class="single-filter col-md-4">
                        <button class="btn" onclick="findteach()">Find Teacher</button>
                    </div>
                  
                </div>
            </div>
        </div>
        <div class="row">
            
            <div class="col-md-9 col-sm-8 course-grid1">

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/IMG_20170509_122559.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/facultydetail/show/10685" target="_self">Manoj Parmar</a></h3>
                            <span>Head Of Department</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;manojec@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/facultydetail/show/10685">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/BGP1-11.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/facultydetail/show/12096" target="_self">Bhadresh Prajapati</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;b_g_prajapati@yahoo.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/facultydetail/show/12096">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/DMT.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11004" target="_self">Darshana Trivedi</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;trivedidarshna@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11004">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/DSC_0267.JPG" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11855" target="_self">Dineshkumar Patel</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;dvpatel100@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11855">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/IMG-20160328-WA0017_(1).jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11007" target="_self">Devika Gadhavi</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;devika.gadhavi.dg@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11007">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/WP_20160315_12_26_55_Pro-283x300.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11010" target="_self">Krunal Prajapati</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;kkprajapati.it@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11010">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/Janak_Thakkar.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11837" target="_self">Janak Thakkar</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;janakcthakkar@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11837">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <div class="single-teacher-list row no-margin mt-30">
                    <div class="pl-n col-md-4 col-sm-5 col-xs-12">
                        <div class="teacher-img">
                            <img src="http://www.rcti.cteguj.in/uploads/faculty/VGG-1-300x300.jpg" height="200px" width="232px">  
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-8 col-xs-12">
                        <div class="teacher-list-content">
                            <h3><a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11581" target="_self">Vipul Gajjar</a></h3>
                            <span>Lecturer</span><br><br>
                            <h4 style="margin-bottom: 10px;"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;vipulgajjar.bece@gmail.com</h4>
                            <br>
                            <a href="http://www.rcti.cteguj.in/index.php/facultydetail/show/11581">Read More <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
        <script type="text/javascript">
            function findteach() {
                var text = document.getElementById('teach').value;
                window.find(text);
            }

        </script>
    </body>


</html>
<?php 
    session_start();
    if(!isset($_SESSION["sUsername"]))
        header("location:login.php");
    $sid=$_SESSION["sid"];

    include 'connectDB.php';

    $res=$conn->query("select * from student where sid='$sid'");
    $row=$res->fetch_object();
    $sugres=$conn->query("select sugmsg,sug_date from suggestion where sid='$sid'");

?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <script src="https://use.fontawesome.com/aa08088a96.js"></script>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Add Favicon -->
    <link rel="shortcut icon" href="img/logo/favicon.png">
    <!-- Author Meta -->
    <meta name="author" content="CodePixar">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="utf-8">
    <!-- Site Title -->
    <title>ELP</title>

    <!--
        CSS
        ============================================= -->
    <style type="text/css">
        button {
            background-color: white;
            border: none;
        }
        }
    </style>
    <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/materialize.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/et-line.css">
    <!-- <link rel="stylesheet" href="css/animate.css"> -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/slicknav.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/main.css">
    <!-- <link rel="stylesheet" href="css/minified.css"> -->

</head>

<body>

    <!-- header start-->

    <?php include 'common/header.php'; ?>

    <!-- header end -->
    <div class="search-area">
        <div class="container">
            <div class="row fitscreen flex flex-middle relative">
                <form action="#" class="search-form">
                    <input id="focus" placeholder="Search your query and press “Enter”" type="text">
                </form>
            </div>
        </div>
    </div>
    <main>
        <!-- Static Banner Area Start -->
        <section id="slider">
            <div class="static-banner relative">
                <div class="overlay blue-overlay-5"></div>
                <div class="page-head">
                    <h2 class="page-title"><?php echo "$row->sfname "."$row->slname"; ?></h2>
                    <ul class="page-title-btn">
                        <li><a href="#" target="_self">Home<i class="fa fa-caret-right"
                                    aria-hidden="true"></i></a></li>
                        <li><a href="#" class="active">Profile</a></li>
                    </ul>
                </div>
            </div>
        </section>                                             
        <!-- Static Banner Area End -->
        <!-- Web Design Course Area Start -->
        <section class="section-full teacher-details">
            <div class="container">
                <div class="row">
                    <div class="web-course">
                        <div class="col-md-9 col-xs-12">
                            <div class="left-web-course">
                                <div class="teacher-top flex">
                                    <div class="teacher-img">
                                        <img src="<?php if($row->sgender=="male"){echo "img/he.png";}else{echo "img/she.png";}?>" alt="" class="img-responsive">
                                    </div>
                                    <div class="teacher-top-content">
                                        <h2><?php echo "$row->sfname "."$row->slname"; ?></h2>
                                        <p>At <?php echo $row->sdept ?> department</p>
                                    </div>
                                </div>
                                <div class="tab-menu mt-20">
                                    <ul id="tabs-swipe-demo" class="tabs course-tab">
                                        <li class="tab"><a href="#about">About Me</a></li>

                                        <li class="tab"><a href="#reviews">My Reviews</a></li>
                                    </ul>
                                </div>
                                <div id="about" class="about mt-30">

                                    <div id="about" class="about mt-30">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">

                                                        <div class="single-info flex space-between">
                                                            <h4>Name</h4>
                                                            <h4><?php echo "$row->sfname "."$row->slname"; ?></h4>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">

                                                        <div class="single-info flex space-between">
                                                            <h4>Enrollment</h4>
                                                            <h4><?php echo $row->senroll ?></h4>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">

                                                        <div class="single-info flex space-between">
                                                            <h4>Gender</h4>
                                                            <h4><?php echo $row->sgender ?></h4>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">

                                                        <div class="single-info flex space-between">
                                                            <h4>Joining Date</h4>
                                                            <h4><?php echo $row->sreg_date ?></h4>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">
                                                        <div class="single-info flex space-between">
                                                            <h4>Email</h4>
                                                            <h4><?php echo $row->semail ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">
                                                        <div class="single-info flex space-between">
                                                            <h4>Conact</h4>
                                                            <h4><?php echo $row->scontact ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">
                                                        <div class="single-info flex space-between">
                                                            <h4>Department</h4>
                                                            <h4><?php echo $row->sdept ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-xs-12">
                                                    <div class="right-web-course">
                                                        <div class="single-info flex space-between">
                                                            <h4>D.O.B.</h4>
                                                            <h4><?php echo $row->sdob ?></h4>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-12 col-xs-12">
                                            <div class="right-web-course">
                                                <div class="single-info flex space-between">
                                                    <h4>Address</h4>
                                                    <h4><?php echo $row->saddress ?></h4>
                                                </div>
                                            </div>
                                        </div><a href="update.php">
                                        <button class="btn submit-btn" style="margin-top:30px;">Edit</button></a>                                                                          


                                </div>

                            </div>

                            <div id="reviews" class="reviews mt-30">
                                <!--  <div class="teacher-rating-top flex no-flex-xs">
                                
                            </div> -->
                                <!-- <div class="total-comment mt-50">
                                    <div class="single-comment mt-30">
                                        <div class="comment-head">
                                            <div class="media">
                                                <div class="media-body">
                                                    <h4 class="media-heading">Dorethy Kallyas</h4>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="comment-body">
                                            <p class="mt-15">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                                                enim ad minim veniam.</p>
                                        </div>
                                    </div> -->

                                    <?php while($sugrow=$sugres->fetch_object()){ ?>
                                    
                                    <div class="total-comment mt-50">
                                        <div class="single-comment mt-30">
                                            <div class="comment-head">
                                                <div class="media">
                                                    <div class="media-body">
                                                        <h4 class="media-heading"><?php echo "$row->sfname "."$row->slname   "; ?>|<?php echo "  $sugrow->sug_date"; ?></h4>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="comment-body">
                                                <p class="mt-15"><?php echo $sugrow->sugmsg;?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            </div>
        </section>
        <!-- / #Web Design Course End -->
    </main>
    <!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
    <!-- Footer Area End -->

    <!--
        JavaScripts
        ========================== -->
    <script src="js/vendor/jquery-2.2.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/vendor/materialize.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
    <script src="js/jquery.nice-select.js"></script>
    <script src="js/jquery.jCounter-0.1.4.js"></script>
    <script src="js/main.js"></script>
    <!-- <script src="js/minified/minified.js"></script> -->
    <script src="js/map-init.js"></script>
</body>

</html>
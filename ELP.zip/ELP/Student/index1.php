<?php 
 session_start();
// if(!isset($_SESSION["sUsername"]))
//     header("location:login.php");


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.svg">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <style>.links:hover{color: #f85b31;}</style>
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>

        <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->

<main>
<section id="slider" class="slider-section">
    <div class="slider1 deafult-slider">
        <div class="item fullscreen flex flex-middle" style="background-image: url(img/slider/1.jpg);">
            <div class="container">
                <div class="col-lg-offset-6 col-lg-6 col-md-12">
                    <div class="slide-content">
                        <h1 class="light h1">Introducing <br> E-Learning Platform</h1>
                        <p class="light mt-10">A web application to help you learn from anywhere, anytime!</p>
                        <a href="login.php" target="_self" class="btn mt-10 mr-10">Start Now</a>
                  
                    </div>
                </div>
            </div>
            <div class="overlay-slider"></div>
        </div>
        <div class="item fullscreen flex flex-middle" style="background-image: url(img/slider/5.jpg);">
            <div class="container">
                <div class="col-lg-6 col-md-12">
                    <div class="slide-content">
                        <h1 class="light h1">We are ready to take the challenge</h1><br>
                        <a href="courses.php" target="_self" class="btn mt-10 mr-10">Start Now</a>
                        <!-- <a href="09-about.html" target="_self" class="btn mt-10">Read More</a> -->
                    </div>
                </div>
            </div>
            <div class="overlay-slider2"></div>
        </div>
    </div>
</section>


<!-- Chose Course Area Start -->
<!-- <section id="chose-course" class="bg-gray section-full" >
    <div class="container">
        <div class="chose-course"> -->
            <!-- <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <div class="section-head text-center pb-100" style="padding-bottom: 50px;">
                        <h2 class="first-title">Choose Your Subject</h2>
                     
                    </div>
                </div>
            </div> -->
            
            <!-- <div class="row">
                <div class="chose-course-body">

                    <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>
                     <div class="col-md-4 col-sm-6">
                        <div class="media single-course">
                            <div class="media-left">
                                <a href="14-course-details.html" target="_self">
                                    <img class="media-object" src="img/course/1.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="14-course-details.html" target="_self">Android Development</a></h4>
                                <h5 style="margin-top: 15px;">Subject Code: 3361602</h5>
                                <h4 class="media-heading" style="margin-top: 30px;margin-bottom: 0px;"><a href="14-course-details.html" target="_self" >Visit</a></h4>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 mt-30 text-center">
                    <a href="10-course-grid-01.html" target="_self" class="btn">View All Courses</a>
                </div>
            </div> -->
<!--         </div>
    </div>
</section> -->
<!-- / #Chose Course End  -->

<!-- Testimonial Area Start -->
<section class="testimonial-1" style="
    padding-bottom: 200px;
">
    <div class="container">
        <div class="row no-margin">
            <div class="col-sm-offset-1 col-sm-offset-11">
                <div class="testimonial-border">
                    <div class="test-img hidden-xs hidden-sm">
                        <img src="img/testimonial/t1.png" class="img-responsive" alt="">
                    </div>
                    <div class="row">
                        <div class="col-sm-offset-6 col-sm-6">
                            <div class="testimonial-content">
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>Education is the best friend. An educated person is respected everywhere. Education beats the beauty and the youth.</p>
                                    <h6>Chankya</h6>
                                    <!-- <span>Adobe Indesign</span> -->
                                </div>
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>The object of education is to prepare the young to educate themselves throughout their lives.</p>
                                    <h6>Robert M. Hutchins</h6>
                                    <!-- <span>Adobe Indesign</span> -->
                                </div>
                                <div class="item">
                                    <i class="fa fa-quote-left"></i>
                                    <p>An education isn't how much you have committed to memory, or even how much you know. It's being able to differentiate between what you know and what you don't.</p>
                                    <h6>Anatole France</h6>
                                    <!-- <span>Adobe Indesign</span> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Area End -->


<!-- Notice Board End -->
<!-- <section class="cta-1">
    <div class="cta-bg relative mb-2"  data-velocity=".2">
        <div class="overlay cta-overlay-bg"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="cta-content">
                        <h2>Join Over 59264 Students</h2>
                        <a href="12-course-list-01.html" target="_self" class="btn">Join ELP Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
 -->

</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
        <script >$(window).on("scroll", function() {
    if($(window).scrollTop() > 800) {
        $(".header").addClass("active");
    } else {
        //remove the background property so it comes transparent again (defined in your css)
       $(".header").removeClass("active");
    }
});</script>
    </body>

</html>
<?php 
    session_start();
    if(!isset($_SESSION["sUsername"])){
        header("location:login.php");    
    }
    if(isset($_GET["subcode"])){
        $subcode=$_GET["subcode"];    
    }
    if(isset($_GET["chnum"])){
        $chnum=$_GET["chnum"];    
    }   

    $chaptered=false;

    include 'connectDB.php';
    
    if(isset($subcode)&&isset($chnum))
    {
        $chres=$conn->query("select * from notes where subcode='$subcode' and nchapter='$chnum'");
        $chaptered=true;
    }
    else if(isset($subcode))
    {
        $res=$conn->query("select * from notes where subcode='$subcode'");    
    }


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        <script></script>
        <!--
        CSS
        ============================================= -->
        <style type="text/css">a{margin-right: 15px;} .desc{height: 4em; overflow-y: scroll;-webkit-mask-image: linear-gradient(180deg, #000 80%, transparent);}</style>
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>
       <?php include 'common/header.php'; ?>

<main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Notes List</h2>
            <ul class="page-title-btn">
                <li><a href="#" target="_self">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Notes List</a></li>
            </ul>
        </div>
    </div>
</section>
<!-- Static Banner Area End -->
<!-- Regular Course Area Start -->
<section class="section-full course-grid1">
    <div class="container">
        
        <div class="row">
            <div class="col-sm-12">
                <!-- <div class="single-list-course row no-gutter">
                    <div class="col-xs-12 col-sm-4">
                        <iframe src="https://drive.google.com/file/d/1X7ha7z-uGaBz9tzhf4mY1_QoSUqH_fXY/preview" style="width: 100%; height: 212px;" allow="autoplay" allowfullscreen="allowfullscreen"></iframe>
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content" style="height: 212px;">
                            <h3><a href="14-course-details.php" target="_self">Photography Course</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="14-course-details.php" target="_self" class="learn">Notes<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                    <a href="14-course-details.php" target="_self" class="learn">Notes<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

<!-- ************Chapter wise videos************ -->

               <?php 
                    if($chaptered)
                    {
                        while ($row=$chres->fetch_object())
                        {
                            $profres=$conn->query("select pfname,plname from professor where prof_id='$row->prof_id'");
                            $profrow=$profres->fetch_object();
                          
                ?>

                <div class="single-list-course row no-gutter" style="display: flex;">
                    <div class="col-xs-12 col-sm-4" style="flex: 1;">
                        <iframe src="<?php echo $row->nvid_url; ?>" style="width: 100%; height: 100%;"  allow="autoplay" allowfullscreen="allowfullscreen"></iframe>
                    </div>
                    <div class="col-xs-12 col-sm-8">
                        <div class="list-course-content" style="flex: 1;">
                            <h3><a href="<?php echo $row->nvid_url; ?>" target="_self"><?php echo $row->ntite; ?></a></h3>
                            <p>By: <?php echo "$profrow->pfname "."$profrow->plname"; ?></p>
                            <p class="desc"><?php echo $row->ndesc; ?></p>
                            <div class="course-bottom-list flex space-between">
                                <div class="single-bottom learn-b">
                                    <a href="<?php echo $row->ndoc_url; ?>" target="_self" class="learn">Notes<i class="ml-10 fa fa-caret-right" aria-hidden="true"></i></a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php 

                      }
                    } 
                ?>

<!-- *********Subject wise videos************* -->

                <?php
                    if(!$chaptered)
                    { 
                        while ($row=$res->fetch_object())
                        {
                            $profres=$conn->query("select pfname,plname from professor where prof_id='$row->prof_id'");
                            $profrow=$profres->fetch_object();
                ?>

                    <div class="single-list-course row no-gutter" style="display: flex;">
                        <div class="col-xs-12 col-sm-4" style="flex: 1;">
                            <iframe src="<?php echo $row->nvid_url; ?>" style="width: 100%; height: 100%;" allow="autoplay" allowfullscreen="allowfullscreen"></iframe>
                        </div>
                        <div class="col-xs-12 col-sm-8">
                            <div class="list-course-content" style="flex: 1;">
                                <h3><a href="<?php echo $row->nvid_url; ?>" target="_self"><?php echo $row->ntite; ?></a></h3>
                                <p>By: <?php echo "$profrow->pfname "."$profrow->plname"; ?></p>
                                <p class="desc"><?php echo $row->ndesc; ?></p>
                                <div class="course-bottom-list flex space-between">
                                    <div class="single-bottom learn-b">
                                        <?php 
                                        if($row->ndoc_url!="")
                                        {
                                        echo "<a href=\"$row->ndoc_url\" target=\"_self\" class=\"learn\">Notes<i class=\"ml-10 fa fa-caret-right\" aria-hidden=\"true\"></i></a>";
                                        }
                                        else
                                            echo "";
                                         ?>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php 
                        } 
                    }
                ?>

            </div>
        </div>
        
    </div>
</section>
<!-- / #Regular Course End -->

</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>
</html>
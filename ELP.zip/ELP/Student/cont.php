<?php 
session_start();
if(!isset($_SESSION["sUsername"]))
    header("location:login.php");


?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
        <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Add Favicon -->
        <link rel="shortcut icon" href="img/logo/favicon.png">
        <!-- Author Meta -->
        <meta name="author" content="CodePixar">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="utf-8">
        <!-- Site Title -->
        <title>ELP</title>
        
        <!--
        CSS
        ============================================= -->
        <link href="https://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/materialize.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/et-line.css">
        <!-- <link rel="stylesheet" href="css/animate.css"> -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/slicknav.css">
        <link rel="stylesheet" href="css/flaticon.css">
        <link rel="stylesheet" href="css/main.css">
        <!-- <link rel="stylesheet" href="css/minified.css"> -->
        
    </head>
    <body>
 <!-- header start-->

        <?php include 'common/header.php'; ?>

        <!-- header end -->
<div class="search-area">
    <div class="container">
        <div class="row fitscreen flex flex-middle relative">
            <form action="#" class="search-form">
                <input id="focus" placeholder="Search your query and press “Enter”" type="text">
            </form>
        </div>
    </div>
</div>
<main>
<!-- Static Banner Area Start -->
<section id="slider">
    <div class="static-banner relative">
        <div class="overlay blue-overlay-5"></div>
        <div class="page-head">
            <h2 class="page-title">Contact Us</h2>
            <ul class="page-title-btn">
                <li><a href="01-home-university.html" target="_self">Home <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#">Pages <i class="fa fa-caret-right" aria-hidden="true"></i></a></li>
                <li><a href="#" class="active">Contact Us</a></li>
            </ul>
        </div>
    </div>   
</section>
<!-- Static Banner Area End -->
<section class="contact relative">
    <div class="bg-left"></div>
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="address-content flex flex-column flex-center no-flex-xs">
                    <div class="single-address flex">
                        <div class="icon">
                            <span class="et-line icon-map-pin"></span>
                        </div>
                        <div class="body">
                            <p>Opp Civil, Near Gujarat High Court, S.G.Highway, Sola, Ahmedabad, Gujarat 380060</p>
                        </div>
                    </div>
                    <div class="single-address flex">
                        <div class="icon">
                            <span class="et-line icon-megaphone"></span>
                        </div>
                        <div class="body">
                            <a href="tel:+00(012)9105642568">0123456789</a> <br>
                            <a href="tel:+00(012)9105642569">0123456789</a>
                        </div>
                    </div>
                    <div class="single-address flex">
                        <div class="icon">
                            <span class="et-line icon-envelope"></span>
                        </div>
                        <div class="body">
                            <a href="mailto:info@elp.com">info@elp.com</a> <br>
                            <a href="mailto:support@elp.com">support@elp.com</a>
                        </div>
                    </div>
                    <div class="single-address flex">
                        <div class="icon">
                            <span class="et-line icon-global"></span>
                        </div>
                        <div class="body">
                            <a href="#">www.elp.com.in</a> <br>
                            <a href="#">www.elp-business.com.in</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-offset-1 col-md-5 col-sm-6 col-xs-12">
                <div class="contact-right flex flex-column flex-center no-flex-xs">
                    <div class="right-head"><h3>Need Help? Send us a message :)</h3>
                    <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                    eiusmod tempor incididunt ut labore et dolore magna aliquaut enim</p> -->
                    </div>
                    <div class="leave-comment">
                        <form id="myForm" action="https://demo.nurcodes.com/E-LMS/php/mail.php" method="post">
                            <p><input placeholder="Full Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Full Name'" type="text" name="fname" required></p>
                            <p><input pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" name="email" required></p>
                            <p><input placeholder="Subject" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Subject'" type="text" name="subject" required></p>
                            <p><textarea placeholder="Message" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Message'" name="message" required></textarea></p>
                            <p><button class="btn submit-btn" type="submit">Send Message</button></p>
                            <div class="alert"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
</section>

</main>
<!-- Footer Area Start -->
    <?php include 'common/footer.php'; ?>
<!-- Footer Area End -->
        
        <!--
        JavaScripts
        ========================== -->
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/materialize.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.sticky.js"></script>
        <script src="js/jquery.slicknav.min.js"></script>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCqCaX4fFEQRiTJoeclXKZRaFh2fYfps_Y"></script>
        <script src="js/jquery.nice-select.js"></script>
        <script src="js/jquery.jCounter-0.1.4.js"></script>
        <script src="js/main.js"></script>
        <!-- <script src="js/minified/minified.js"></script> -->
        <script src="js/map-init.js"></script>
    </body>


</html>
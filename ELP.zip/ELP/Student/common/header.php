
<?php
    // session_start();
    if(isset($_SESSION["sdept"]))
    {
        $sdept=$_SESSION["sdept"];
    }
  ?>
<header id="header1" class="blue-bg default-header" >
        <div class="container" >
            <div class="navbar-area flex space-between">
                <div class="left-bar">
                    <div class="logo">
                        <a href="#">
                            <img src="img/logo/nameLogo.svg" height="34" width="165" alt="">
                        </a>
                    </div>
                </div>
                <div class="right-bar flex float-right">
                    <nav>
                        <ul id="mobile" class="main-menu  hidden-xs">
                            <li class="cpage"><a href="#">Home</a>
                                <ul class="sub-menu">
                                                                 
                                    <li><a href="index1.php" target="_self">Home Online Education</a></li>
    
                                </ul>
                            </li>
                            <li class="cpage"><a href="#">Subjects</a>
                                <ul class="sub-menu">
                                    <li><a href="courses.php?department=<?php echo "$sdept"; ?>" target="_self">Subjects Available!</a></li>                             
                                   
    
                                </ul>
                            </li>
                            <li class="cpage"><a href="#">Instructor</a>
                                <ul class="sub-menu">
                                    
                                    <li><a href="profslist.php" target="_self">Teacher List</a></li> 
                                </ul>
                            </li>

                            <li class="cpage"><a href="#">About</a>
                                <ul class="sub-menu">
                                                                 
                                    <!-- <li><a href="about.php" target="_self">About ELP </a></li> -->
                                    <li><a href="colleges.php" target="_self">Colleges</a></li> 
    
                                </ul>
                            </li>
<!-- 
                            <li class="cpage"><a href="#">Contact</a>
                                <ul class="sub-menu">
                                                                 
                                    <li><a href="cont.php" target="_self">Contact Us</a></li> 
    
                                </ul>
                            </li> -->

                            
                            
                            <li class="cpage"><a href="#">Profile</a>
                                <ul class="sub-menu">           
                                    <li><a href="profile.php" target="_self">Profile</a></li>                                   
                                    <li><a href="logout.php" target="_self">Logout</a></li>                        
                                </ul>
                            </li>
                        </ul>
                    </nav>

                </div>
            </div>
        </div>
    </header>
    <script type="text/javascript">

        var path = window.location.pathname;
        var page = path.split("/").pop();
        mypage = page.split(".", 1);

            if(mypage=="index1"){
                document.getElementsByClassName("cpage")[0].classList.add("my-active");
            }
            else if(mypage=="courses"){
                document.getElementsByClassName("cpage")[1].classList.add("my-active");
            }
            else if(mypage=="coursedet"){
                document.getElementsByClassName("cpage")[1].classList.add("my-active");
            }
            else if(mypage=="notelist"){
                document.getElementsByClassName("cpage")[1].classList.add("my-active");
            }
            else if(mypage=="profslist"){
                document.getElementsByClassName("cpage")[2].classList.add("my-active");
            }
            else if(mypage=="about"){
                document.getElementsByClassName("cpage")[3].classList.add("my-active");
            }
            else if(mypage=="colleges"){
                document.getElementsByClassName("cpage")[3].classList.add("my-active");
            }
            else if(mypage=="cont"){
                document.getElementsByClassName("cpage")[4].classList.add("my-active");
            }
            else if(mypage=="teach"){
                document.getElementsByClassName("cpage")[5].classList.add("my-active");
            }

    </script>


<head>
    <style type="text/css">
        .second-title{color: white;}
        .links{color: white;}
    </style>
</head>
<footer id="footer1" class="bg-gray" style="background-color: #001e32; color: white;">
    <div class="container">
        <div class="row">
            <div class="footer-widget">
                <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                    <div class="footer-widget-address">
                        <img src="img/footer/1.jpg" alt="" class="img-responsive">
                        <ul class="footer-address">
                            <!-- <li><span class="et-line icon-map-pin"></span>56/8, West panthapath,India.</li> -->
                            <li><span class="et-line icon-mic"></span> +00 0123456789</li>
                            <li><span class="et-line icon-global"></span>www.elp.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                    <div class="footer-widget-link">
                        <h4 class="second-title">Useful Links</h4>
                        <div class="row">
                            <div class="col-sm-4">
                                <ul>
                                    <li><a href="colleges.php" target="_self">About Us</a></li>
                                    <!-- <li><a href="32-blog-home.html" target="_self">Blog</a></li> -->
                                    <!-- <li><a href="colleges.php" target="_self">Contact</a></li> -->
                                    <li><a href="courses.php" target="_self">Courses</a></li>
                            
                                </ul>
                            </div>
                  
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                    <div class="footer-widget-course">
                        <h4 class="second-title">Recent Courses</h4>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="courses.php" target="_self">
                                    <img class="media-object" src="img/footer/2.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="coursedet.php" target="_self">Android App Development</a></h4>
                                
                            </div>
                        </div>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="courses.php" target="_self">
                                    <img class="media-object" src="img/footer/3.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="coursedet.php" target="_self">Web development with PHP</a></h4>
                                
                            </div>
                        </div>
                        <div class="media single-widget-course">
                            <div class="media-left">
                                <a href="courses.php" target="_self">
                                    <img class="media-object" src="img/footer/2.jpg" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="coursedet.php" target="_self"> Advance Java Programming</a></h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3 col-xs-12 tb-height">
                    <div class="footer-widget-contact">
                        <h4 class="second-title">Send Message</h4>
                        <form action="#" >
                            <p><input style="color: white;" placeholder="Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'" type="text" required></p>
                            <!-- <p><input style="color: white;" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" type="email" required></p> -->
                            <p><textarea style="color: white;" cols="30" rows="10" placeholder="Comment" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Comment'" required></textarea></p>
                            <p><button class="btn submit-btn">Send</button></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">

                <br><br>
            </div>
        </div>
    </div>
</footer>
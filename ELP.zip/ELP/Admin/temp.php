<?php
  
//   // This function will return 
//   // A random string of specified length
//   function random_strings($length_of_string) {
        
     
//     // sha1 the timstamps and returns substring
//     // of specified length
//     return substr(sha1(time()), 0, $length_of_string);
// }
  
// // This function will generate 
// // Random string of length 10
// echo  random_strings(10);
  
// echo "\n";
  
// // This function will generate 
// // Random string of length 8
// echo  random_strings(8);

for ($i=0; $i <10 ; $i++) { 
	# code...
	echo time();
	echo "<br>";
}
  

$data = array(
	"Peter"=>"35", 
	"Ben"=>"37",
	"adi"=>"", 
	"Joe"=>"43"
);


?>
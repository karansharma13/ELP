<?php 


	include 'connectDB.php';	

	$id = $_GET["deleteid"];

	$exe=$conn->query("delete from student where sid='$id'");

	if ($exe) {
		header("location:allstudent.php");
	}
	else
	{
		echo "Error in code...";
	}

 ?>
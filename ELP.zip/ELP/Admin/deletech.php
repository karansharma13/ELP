<?php 
	

		include 'connectDB.php';
		
			
		$subc=$_GET["subcode"];
		$id = $_GET["deleteid"];
	
		$exe=$conn->query("delete from subchap where chid='$id'");
	
		if ($exe) {
			header("location:addch.php?subcode=$subc");
		}
		else
		{
			echo "Error in code...";
		}


 ?>
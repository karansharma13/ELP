<?php 

	
	include 'connectDB.php';

	$id = $_GET["deleteid"];

	$exe=$conn->query("delete from suggestion where sugid='$id'");

	if ($exe) {
		header("location:suggestion.php");
	}
	else
	{
		echo "Error in code...";
	}

 ?>
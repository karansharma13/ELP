<?php 
    session_start();
    if(!isset($_SESSION['username'])){
     header("Location:index.php");
    }

    include 'connectDB.php';
    
    $res=$conn->query("select * from suggestion");   


 ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <style type="text/css">
        main {
            padding-right: 0px;
        }
        span{
            display: inline-block;
            justify-content: space-between;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ELP</title>
    <!-- Iconic Fonts -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">
    <link rel="stylesheet" href="vendors/iconic-fonts/font-awesome/css/all.min.css">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery UI -->
    <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
    <!-- Weeducate styles -->
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon"  href="assets/img/weicon/favicon.svg">

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme ">

    <?php include 'common/sidebar.php'; ?>
    <!-- Main Content -->
    <main class="body-content">

        <?php include 'common/navbar.php'; ?>



        <!-- Body Content Wrapper -->
        <div class="ms-content-wrapper">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb pl-0">
                            <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Suggestions</li>
                        </ol>
                    </nav>

                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>SUGGESTIONS</h6>

                        </div>

                        <div class="ms-panel-body">
                            <div class="accordion has-gap ms-accordion-chevron" id="accordionExample2">
                                <!-- <div class="card">
                                    <div class="card-header" data-toggle="collapse" role="button"
                                        data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour" >
                                        
                                         <h3 style="margin-bottom: 0px;">By: Aditya Vyas| Subject: PHP <span style="float: right;margin-right: 2em;">12/05/2002</span></h3>
                                        
                                    </div>

                                    <div id="collapseFour" class="collapse show" data-parent="#accordionExample2">
                                        <div class="card-body">
                                            Leverage agile frameworks to provide a robust synopsis for high level
                                            overviews. Iterative approaches to corporate strategy foster collaborative
                                            thinking to further the overall value proposition.
                                            Organically grow the holistic world view of disruptive innovation via
                                            workplace diversity and empowerment.
                                        </div>
                                    </div>
                                </div> -->
                                
                                <?php
                                $count=1;
                                while ($row=$res->fetch_object()) {
                                        $studres=$conn->query("select sfname,slname from student where sid='$row->sid' ");
                                        $subres=$conn->query("select subname from subject where subcode='$row->subcode' ");
                                        $studrow=$studres->fetch_object();
                                        $subrow=$subres->fetch_object();
                                        
                                ?>
                                <div class="card" style="width: 95%">
                                    <div class="card-header" data-toggle="collapse" role="button"
                                        data-target="#collapse<?php echo $count; ?>" aria-expanded="false" aria-controls="collapse<?php echo $count; ?>" >
                                        
                                         <h3 style="margin-bottom: 0px;">
                                            By: <?php echo "$studrow->sfname $studrow->slname"  ?>
                                            | Subject: <?php echo $subrow->subname; ?> 
                                            <span style="float: right;margin-right: 2em;"><?php echo $row->sug_date;?></span>
                                        </h3>
                                        
                                    </div>

                                    <div id="collapse<?php echo $count; ?>" class="collapse" data-parent="#accordionExample2">
                                        <div class="card-body">
                                            <?php echo $row->sugmsg; ?><br>
                                            <h3 style="margin: 10px 0 0 0;">
                                                <a href="deletesug.php?deleteid=<?php echo $row->sugid ?>">Delete</a>
                                            </h3>
                                        </div>
                                    </div>

                                </div>
                                
                            <?php $count++; } ?>

                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div>
        </div>

    </main>



    <!-- SCRIPTS -->
    <!-- Global Required Scripts Start -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/perfect-scrollbar.js"> </script>
    <script src="assets/js/jquery-ui.min.js"> </script>
    <!-- Global Required Scripts End -->

    <!-- Weeducate core JavaScript -->
    <script src="assets/js/framework.js"></script>

    <!-- Settings -->
    <script src="assets/js/settings.js"></script>

</body>


<!-- Mirrored from metropolitanhost.com/themes/templatemoster/html/weeducate/pages/prebuilt-pages/faq.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Jan 2022 09:52:45 GMT -->

</html>
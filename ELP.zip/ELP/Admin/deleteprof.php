<?php 


	include 'connectDB.php';

	$id = $_GET["deleteid"];

	$exe=$conn->query("delete from professor where prof_id='$id'");

	if ($exe) {
		header("location:allprofessor.php");
	}
	else
	{
		echo "Error in code...";
	}

 ?>
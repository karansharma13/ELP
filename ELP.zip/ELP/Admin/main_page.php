<?php 

  session_start();
  if(!isset($_SESSION['username'])){
     header("Location:index.php");
  }
  include 'connectDB.php';
      
 ?>
<!DOCTYPE html>
<html lang="en">



<head>

  <style type="text/css">main{padding-right: 0px;} </style>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>ELP</title>
  <!-- Iconic Fonts -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="vendors/iconic-fonts/font-awesome/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">
  
  <!-- Bootstrap core CSS -->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <!-- jQuery UI -->
  <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
  <!-- Page Specific CSS (Slick Slider.css) -->
  <link href="../assets/css/slick.css" rel="stylesheet">
  <!-- Weeducate styles -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- Favicon -->
  <link rel="icon"  href="assets/img/weicon/favicon.svg">

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme ">

  <!-- Setting Panel -->

  <!-- Preloader -->

  <!-- Overlays -->

  <?php include 'common/sidebar.php'; ?>

  <!-- Sidebar Right -->

  <!-- Main Content -->
  <main class="body-content">

    <!-- Navigation Bar -->
    
    <?php include 'common/navbar.php'; ?>

    <!-- Body Content Wrapper -->

    <!-- Body Content Wrapper -->

<div class="ms-content-wrapper">

    <!-- Icon cards Widget -->
  <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="ms-card card-gradient-success ms-widget ms-infographics-widget">
            <div class="ms-card-body media">
              <div class="media-body">
                <h6>Total Students</h6>
                <p class="ms-card-change">450</p>
                
              </div>
            </div>
            <i class="fa fa-users"></i>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="ms-card card-gradient-secondary ms-widget ms-infographics-widget">
            <div class="ms-card-body media">
              <div class="media-body">
                <h6>Total Teachers</h6>
                <p class="ms-card-change">50</p>                
              </div>
            </div>
            <i class="fas fa-chalkboard-teacher fs-16"></i>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="ms-card card-gradient-warning ms-widget ms-infographics-widget">
            <div class="ms-card-body media">
              <div class="media-body">
                <h6>Total Subjects</h6>
                <p class="ms-card-change"> 7</p>          
              </div>
            </div>
           <i class="fas fa-book"></i>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
          <div class="ms-card card-gradient-info ms-widget ms-infographics-widget">
            <div class="ms-card-body media">
              <div class="media-body">
                <h6>Total Notes</h6>
                <p class="ms-card-change"> 50</p>               
              </div>
            </div>
            <i class="far fa-clipboard"></i>
          </div>
        </div>
        </div>              
  </div>      
</div>

        <!-- Table -->   
</main>

  <!--   Quick bar -->

 
  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/perfect-scrollbar.js"> </script>
  <script src="assets/js/jquery-ui.min.js"> </script>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <script src="assets/js/Chart.bundle.min.js"> </script>
  <script src="assets/js/index.js"> </script>
  <!-- Page Specific Scripts End -->

  <!-- Weeducate core JavaScript -->
  <script src="assets/js/framework.js"></script>

  <!-- Settings -->
  <script src="assets/js/settings.js"></script>
 <!-- Page Specific Scripts Start -->
  <script src="assets/js/datatables.min.js"> </script>
  <script src="assets/js/data-tables.js"> </script>

</body>
</html>

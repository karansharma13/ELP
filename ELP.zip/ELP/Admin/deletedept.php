<?php 


	include 'connectDB.php';



	$id = $_GET["deleteid"];

	$exe=$conn->query("delete from dept where depid='$id'");

	if ($exe) {
		header("location:dept.php");
	}
	else
	{
		echo "Error in code...";
	}


 ?>
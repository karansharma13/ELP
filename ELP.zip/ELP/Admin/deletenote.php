<?php 


		include 'connectDB.php';

		$id = $_GET["deleteid"];
	
		$exe=$conn->query("delete from notes where nid='$id'");
	
		if ($exe) {
			header("location:allnotes.php");
		}
		else
		{
			echo "Error in code...";
		}

 ?>
<?php 
    session_start();
    if(!isset($_SESSION['username'])){
     header("Location:index.php");
    }

    include 'connectDB.php';
    
    $table="student";
    $id=$_GET['editid'];
    $res=$conn->query("select * from $table where sid='$id' ");
    $row=$res->fetch_object();

    function update($table,$data,$conn,$inid)
    {    



        unset($data["submit"]);

        $temp=array();

        foreach($data as $val1=>$val2)
        {
            
            array_push($temp,"$val1='$val2'");
        
        }
        $values=implode(",",$temp);
        $query="update $table set $values where sid='$inid'";
        $check=$conn->query($query);
        return $check;
    }

    if (isset($_POST["submit"])) 
    {    
        if($_POST["spassword"]=="")
            unset($_POST["spassword"]); 
        else 
            $_POST["spassword"]=md5($_POST["spassword"]);

        $check=update($table,$_POST,$conn,$id);

        if($check)
        {
          header("location:allstudent.php");
        }
        else
        {
          echo "<script>alert('Not Updated!')</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">



<head>

    <style type="text/css">
        main {
            padding-right: 0px;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ELP</title>    <!-- Iconic Fonts -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="vendors/iconic-fonts/font-awesome/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery UI -->
    <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
    <!-- Page Specific CSS (Slick Slider.css) -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Weeducate styles -->
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon"  href="assets/img/weicon/favicon.svg">

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme ">

    <?php include 'common/sidebar.php'; ?>

    <main class="body-content">

        <?php include 'common/navbar.php'; ?>



        <!-- Body Content Wrapper -->

        <!-- Body Content Wrapper -->
        <div class="ms-content-wrapper">
            <div class="row">

                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb pl-0">
                            <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Student</li>
                            <li class="breadcrumb-item active" aria-current="page">Update Student</li>
                        </ol>
                    </nav>
                </div>

                <div class="col-lg-12">
                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>Update Student</h6>
                        </div>
                        <div class="ms-panel-body">
                            <form method="post">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">First Name</label>
                                            <input type="text" class="form-control" id="sfname"
                                                placeholder="First name" name="sfname" value="<?php echo $row->sfname; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Last Name</label>
                                            <input type="text" class="form-control" id="slname"
                                                placeholder="Last name" name="slname" value="<?php echo $row->slname; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="exampleEmail">Email address</label>
                                            <input type="email" class="form-control" id="semail"
                                                placeholder="name@example.com" name="semail" value="<?php echo $row->semail; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Enrollment Number</label>
                                            <input type="text" class="form-control" id="senroll"
                                                placeholder="Enrollment Number" name="senroll" value="<?php echo $row->senroll; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">College Code</label>
                                            <input type="text" class="form-control" id="scol_id"
                                                placeholder="i.e. 640 for RCTI" name="scol_id" value="<?php echo $row->scol_id; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Departement</label>
                                            <select class="form-control" id="sdept" name="sdept">
                                                <!-- <option value="Meachnical" <?php if($row->sdept=="Meachnical") echo "selected"; ?>>Meachnical</option> -->
                                                <?php 
                                                    $depres=$conn->query("select * from dept");
                                                    while($deprow=$depres->fetch_object())
                                                    {
                                                        echo "<option value=\"$deprow->depname\""; 
                                                        if($row->sdept==$deprow->depname)
                                                            echo "selected";
                                                        echo ">$deprow->depname</option>";
                                                    }

                                                 ?>
                                                

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="exampleSelect">Gender</label>
                                            <select class="form-control" id="sgender" name="sgender">
                                                <option value="male" <?php if($row->sgender=="male") echo "selected"; ?>>Male</option>
                                                <option value="female" <?php if($row->sgender=="female") echo "selected"; ?>>Female</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Mobile Number</label>
                                            <input type="text" class="form-control" id="scontact"
                                                placeholder="Mobile Number" name="scontact" value="<?php echo $row->scontact; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Joining Date</label>
                                            <input type="date" class="form-control" id="sreg_date"
                                                placeholder="Joining Date" name="sreg_date" value="<?php echo $row->sreg_date; ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Date of Birth</label>
                                            <input type="date" class="form-control" id="sdob"
                                                placeholder="Date of Birth" name="sdob" value="<?php echo $row->sdob; ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Password</label>
                                            <input type="text" class="form-control" id="spassword"
                                                placeholder="Password" name="spassword">
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="exampleTextarea">Address</label>
                                            <textarea class="form-control" id="saddress" rows="5" name="saddress"><?php echo $row->saddress; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>
                        <center><button type="submit" class="btn btn-warning mb-5" name="submit">Update</button>
                            <button type="reset" class="btn btn-outline-warning mb-5 ml-3">Cancel</button>
                        </center>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </main>


    <!-- SCRIPTS -->
    <!-- Global Required Scripts Start -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/perfect-scrollbar.js"> </script>
    <script src="assets/js/jquery-ui.min.js"> </script>
    <!-- Global Required Scripts End -->

    <!-- Page Specific Scripts Start -->
    <script src="assets/js/slick.min.js"> </script>
    <script src="assets/js/moment.js"> </script>
    <script src="assets/js/jquery.webticker.min.js"> </script>
    <script src="assets/js/Chart.bundle.min.js"> </script>
    <script src="assets/js/Chart.Financial.js"> </script>


    <!-- Weeducate core JavaScript -->
    <script src="assets/js/framework.js"></script>

    <!-- Settings -->
    <script src="assets/js/settings.js"></script>

</body>


<!-- Mirrored from metropolitanhost.com/themes/templatemoster/html/weeducate/pages/professors/addprofessor.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Jan 2022 09:47:21 GMT -->

</html>
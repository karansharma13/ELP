<?php 


	include 'connectDB.php';

	$id = $_GET["deleteid"];

	$exe=$conn->query("delete from subject where subcode='$id'");

	if ($exe) {
		header("location:allsubjects.php");
	}
	else
	{
		echo "<script>alert('Error Occured!')</script>";
	}

 ?>
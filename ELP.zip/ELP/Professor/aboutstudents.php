<?php 
    session_start();
    if(!isset($_SESSION['profusername'])){
     header("Location:index.php");
    }

    include 'connectDB.php';
    
    $table="student";
    $id=$_GET['aboutid'];
    $res=$conn->query("select * from $table where sid='$id' ");
    $row=$res->fetch_object();

    
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <style type="text/css">
        main {
            padding-right: 0px;
        }
    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ELP</title>    <!-- Iconic Fonts -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="vendors/iconic-fonts/font-awesome/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery UI -->
    <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
    <!-- Page Specific CSS (Slick Slider.css) -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Weeducate styles -->
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon"  href="assets/img/weicon/favicon.svg">

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme ">

    <?php include 'common/sidebar.php'; ?>

    <main class="body-content">

        <?php include 'common/navbar.php'; ?>



        <!-- Body Content Wrapper -->

        <!-- Body Content Wrapper -->
        <div class="ms-content-wrapper">
            <div class="row">

                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb pl-0">
                            <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Student</li>
                            <li class="breadcrumb-item active" aria-current="page">Add Student</li>
                        </ol>
                    </nav>
                </div>

                <div class="col-lg-12">
                    <div class="ms-panel">
                        <div class="ms-panel-header">
                            <h6>Add Student</h6>
                        </div>
                        <div class="ms-panel-body">
                            <form method="post">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">First Name</label>
                                            <input type="text" class="form-control" id="sfname"
                                                placeholder="First name" name="sfname" value="<?php echo $row->sfname; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Last Name</label>
                                            <input type="text" class="form-control" id="slname"
                                                placeholder="Last name" name="slname" value="<?php echo $row->slname; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="exampleEmail">Email address</label>
                                            <input type="email" class="form-control" id="semail"
                                                placeholder="name@example.com" name="semail" value="<?php echo $row->semail; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Enrollment Number</label>
                                            <input type="text" class="form-control" id="senroll"
                                                placeholder="Enrollment Number" name="senroll" value="<?php echo $row->senroll; ?>" readonly="">
                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">College Code</label>
                                            <input type="text" class="form-control" id="scol_id"
                                                placeholder="i.e. 640 for RCTI" name="scol_id" value="<?php echo $row->scol_id; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Departement</label>
                                            <select class="form-control" id="sdept" name="sdept" disabled="">
                                                <option value="Meachnical" <?php if($row->sdept=="Meachnical") echo "selected"; ?>>Meachnical</option>
                                                <option value="Computer" <?php if($row->sdept=="Computer") echo "selected"; ?>>Computer</option>
                                                <option value="Electronic" <?php if($row->sdept=="Electronic") echo "selected"; ?>>Electronic</option>
                                                <option value="Electrical" <?php if($row->sdept=="Electrical") echo "selected"; ?>>Electrical</option>
                                                <option value="Civil" <?php if($row->sdept=="Civil") echo "selected"; ?>>Civil</option>
                                                <option value="Architecture" <?php if($row->sdept=="Architecture") echo "selected"; ?>>Architecture</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="exampleSelect">Gender</label>
                                            <select class="form-control" id="sgender" name="sgender" disabled="">
                                                <option value="male" <?php if($row->sgender=="male") echo "selected"; ?>>Male</option>
                                                <option value="female" <?php if($row->sgender=="female") echo "selected"; ?>>Female</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="name">Mobile Number</label>
                                            <input type="text" class="form-control" id="scontact"
                                                placeholder="Mobile Number" name="scontact" value="<?php echo $row->scontact; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Joining Date</label>
                                            <input type="date" class="form-control" id="sreg_date"
                                                placeholder="Joining Date" name="sreg_date" value="<?php echo $row->sreg_date; ?>" readonly="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="date">Date of Birth</label>
                                            <input type="date" class="form-control" id="sdob"
                                                placeholder="Date of Birth" name="sdob" value="<?php echo $row->sdob; ?>" readonly="">
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="exampleTextarea">Address</label>
                                            <textarea class="form-control" id="saddress" rows="5" name="saddress" disabled=""><?php echo $row->saddress; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>
                        
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </main>


    <!-- SCRIPTS -->
    <!-- Global Required Scripts Start -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/perfect-scrollbar.js"> </script>
    <script src="assets/js/jquery-ui.min.js"> </script>
    <!-- Global Required Scripts End -->

    <!-- Page Specific Scripts Start -->
    <script src="assets/js/slick.min.js"> </script>
    <script src="assets/js/moment.js"> </script>
    <script src="assets/js/jquery.webticker.min.js"> </script>
    <script src="assets/js/Chart.bundle.min.js"> </script>
    <script src="assets/js/Chart.Financial.js"> </script>


    <!-- Weeducate core JavaScript -->
    <script src="assets/js/framework.js"></script>

    <!-- Settings -->
    <script src="assets/js/settings.js"></script>

</body>


<!-- Mirrored from metropolitanhost.com/themes/templatemoster/html/weeducate/pages/professors/addprofessor.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 23 Jan 2022 09:47:21 GMT -->

</html>
<?php 
  session_start();
  if(!isset($_SESSION['profusername'])){
     header("Location:index.php");
  }

  include 'connectDB.php';
  $res=$conn->query("select * from subject");   

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <style type="text/css">main{padding-right: 0px;}  </style>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>ELP</title>
  <!-- Iconic Fonts -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="vendors/iconic-fonts/font-awesome/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">
  
  <link rel="icon"  href="assets/img/weicon/favicon.svg">
    
          
  <!-- Bootstrap core CSS -->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <!-- jQuery UI -->
  <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
  <!-- Page Specific CSS (Slick Slider.css) -->
  <link href="assets/css/slick.css" rel="stylesheet">
  <!-- Weeducate styles -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- Favicon -->
  

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme">

  <?php include 'common/sidebar.php'; ?>
  <!-- Main Content -->
  <main class="body-content">

    <!-- Navigation Bar -->
    <?php include 'common/navbar.php'; ?>

    <!-- Body Content Wrapper -->
    
    <!-- Body Content Wrapper -->
    <div class="ms-content-wrapper">
      <div class="row">

        <div class="col-md-12" >
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Subject</li>
                <li class="breadcrumb-item active" aria-current="page">All Subject</li>
            </ol>
          </nav>
        </div>
        
        <div class="col-md-12" >
          <div class="ms-panel">
            <div class="ms-panel-header">
              <div class="d-flex justify-content-between">
                <div >
                  <h6>Subject Table List</h6>
                </div>
                <div class="dropdown ms-panel-dropdown">
                  <a  class="fa fa-plus  mr-5" data-toggle="dropdown"></a>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Add Subject</a>
                  </div>
                </div>  
              </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover thead-primary">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Subject Name</th>
                      <th scope="col">Subject Code</th>
                      <th scope="col">Department</th>
                      <th scope="col">Modify</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- <tr>
                      <th scope="row">1</th>
                      <td>Android Application Development</td>
                      <td>3361602</td>
                      <td>Information Technology</td>
                      <td><a href="#"><i class="fas fa-edit"></i></a><a href="#"><i class="fas fa-trash-alt"></i></a></td>
                    </tr> -->
                    <?php $count=1;
                        while($row=$res->fetch_object())
                        {
                     ?>
                    <tr>
                      <th scope="row"><?php echo $count; $count++; ?></th>
                      <td><?php echo $row->subname; ?></td>                      
                      <td><?php echo $row->subcode; ?></td>                      
                      <td><?php echo $row->subdept; ?></td>
                      <td>
                        <a href="updatesub.php?editid=<?php echo $row->subcode ?>"><i class="fas fa-edit"></i></a>
                        <a href="deletesub.php?deleteid=<?php echo $row->subcode ?>"><i class="fas fa-trash-alt"></i></a>
                        <a href="addch.php?subcode=<?php echo $row->subcode; ?>"><i class="fas fa-list-alt"></i></a>
                      </td>                      
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            
          </div>
        </div>            
      </div>     
    </div>
  </main>


  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/perfect-scrollbar.js"> </script>
  <script src="assets/js/jquery-ui.min.js"> </script>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <script src="assets/js/slick.min.js"> </script>
  <script src="assets/js/moment.js"> </script>
  <script src="assets/js/jquery.webticker.min.js"> </script>
  <script src="assets/js/Chart.bundle.min.js"> </script>
  <script src="assets/js/Chart.Financial.js"> </script>
 
  <!-- Page Specific Scripts Finish -->

  <!-- Weeducate core JavaScript -->
  <script src="assets/js/framework.js"></script>
    <!-- Page Specific Scripts Start -->
  <script src="assets/js/datatables.min.js"> </script>
  <script src="assets/js/data-tables.js"> </script>


  <!-- Settings -->
  <script src="assets/js/settings.js"></script>

</body>

</html>

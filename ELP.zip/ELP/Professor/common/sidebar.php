<!-- Sidebar Navigation Left -->
  <aside id="ms-side-nav" class="side-nav fixed ms-aside-scrollable ms-aside-left">

    <!-- Logo -->
    <div class="logo-sn ms-d-block-lg">
      <a class="pl-0 ml-0 text-center" href="index.html"><img src="assets/img/logo/nameLogo.svg" alt="logo">  </a>
    </div>

    <!-- Navigation -->
    <ul class="accordion ms-main-aside fs-14" id="side-nav-accordion">
        
        <li class="menu-item">
          <a href="main_page.php">
            <span><i class="fas fa-home fs-16"></i>Home</span>
          </a>
        </li>
        
         <!--Courses Start-->
        <li class="menu-item">
            <a href="#" class="has-chevron" data-toggle="collapse" data-target="#courses" aria-expanded="false" aria-controls="dashboard">
               <span><i class="fa fa-graduation-cap fs-16"></i>Subject/Notes</span>
             </a>
            <ul id="courses" class="collapse" aria-labelledby="courses" data-parent="#side-nav-accordion">
              <li> <a href="addsubject.php">Add Subjects</a> </li>
              <li> <a href="allsubjects.php">All Subjects</a> </li>
              <li> <a href="addnote.php">Add Notes</a> </li>
            </ul>
        </li>
        <!-- /Courses End--->
        
        <!--Student Start-->
        <li class="menu-item">
            <a href="#" class="has-chevron" data-toggle="collapse" data-target="#student" aria-expanded="false" aria-controls="dashboard">
               <span><i class="fa fa-users fs-16"></i>Student</span>
             </a>
            <ul id="student" class="collapse" aria-labelledby="courses" data-parent="#side-nav-accordion">
               <li> <a href="allstudent.php">All Students</a> </li>
               <li> <a href="addstudent.php">Add Students</a> </li>
            </ul>
       </li>
        <!-- /Student End--->
        
       
       
        <!--Holiday Start-->
        <li class="menu-item">
          <a href="suggestion.php">
            <span><i class="fas fa-comment fs-16"></i>Suggestions</span>
          </a>
        </li>
        <!-- /Holiday End--->
        <li class="menu-item">
          <a href="profile.php">
            <span><i class="fas fa-user fs-16"></i>Profile</span>
          </a>
        </li>
     
    </ul>


  </aside>
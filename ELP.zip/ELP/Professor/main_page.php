<?php 

  session_start();
  if(!isset($_SESSION['profusername'])){
     header("Location:index.php");
  }

  include 'connectDB.php';
   
  $res=$conn->query("select * from notes"); 
      

  
 ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <style type="text/css">main{padding-right: 0px;} </style>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>ELP</title>
  <!-- Iconic Fonts -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="vendors/iconic-fonts/font-awesome/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="vendors/iconic-fonts/flat-icons/flaticon.css">
  
   <link rel="icon"  href="assets/img/weicon/favicon.svg">
    
          
  <!-- Bootstrap core CSS -->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <!-- jQuery UI -->
  <link href="assets/css/jquery-ui.min.css" rel="stylesheet">
  <!-- Page Specific CSS (Slick Slider.css) -->
  <link href="assets/css/slick.css" rel="stylesheet">
  <!-- Weeducate styles -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!-- Favicon -->
  

</head>

<body class="ms-body ms-aside-left-open ms-primary-theme">

  <?php include 'common/sidebar.php'; ?>
  <!-- Main Content -->
  <main class="body-content">

    <!-- Navigation Bar -->
    <?php include 'common/navbar.php'; ?>

    <!-- Body Content Wrapper -->
    
    <!-- Body Content Wrapper -->
    <div class="ms-content-wrapper">
      <div class="row">

        <div class="col-md-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb pl-0">
              <li class="breadcrumb-item"><a href="#"><i class="material-icons">home</i> Home | All Notes</a></li>
            </ol>
          </nav>
        </div>
        
        <div class="col-md-12">
          <div class="ms-panel">
            <div class="ms-panel-header">
              <div class="d-flex justify-content-between">
                <div >
                  <h6>Notes Table List</h6>
                </div> 
              </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover thead-primary">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Title</th>
                      <th scope="col">Subject</th>
                      <th scope="col">Date</th>
                      <th scope="col">GoTo</th>
                      <th scope="col">Modify</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- <tr>
                      <th scope="row">1</th>
                      <td>PHP Practical</td>
                      <td>PHP</td>
                      <td>20/01/2022</td>
                      <td><a href="#">Go to Note</a></td>
                      <td><a href="#"><i class="fas fa-edit"></i></a><a href="#"><i class="fas fa-trash-alt"></i></a></td>
                    </tr> -->
                    <?php $count=1;
                    while($row=$res->fetch_object()){ 
                      $subres=$conn->query("select subname from subject where subcode='$row->subcode'");
                      $subrow=$subres->fetch_object();
                      ?>
                      <tr>
                      <th scope="row"><?php echo $count;$count++; ?></th>
                      <td><?php echo $row->ntite ?></td>
                      <td><?php echo $subrow->subname ?></td>
                      <td><?php echo $row->n_date ?></td>
                      <td><a href="<?php echo $row->nvid_url; ?>">Go to Note</a></td>
                      <td><a href="updatenote.php?editid=<?php echo $row->nid; ?>"><i class="fas fa-edit"></i></a><a href="deletenote.php?deleteid=<?php echo $row->nid; ?>"><i class="fas fa-trash-alt"></i></a></td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            
          </div>
        </div>            
      </div>     
    </div>

  </main>


  <!-- SCRIPTS -->
  <!-- Global Required Scripts Start -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/perfect-scrollbar.js"> </script>
  <script src="assets/js/jquery-ui.min.js"> </script>
  <!-- Global Required Scripts End -->

  <!-- Page Specific Scripts Start -->
  <script src="assets/js/slick.min.js"> </script>
  <script src="assets/js/moment.js"> </script>
  <script src="assets/js/jquery.webticker.min.js"> </script>
  <script src="assets/js/Chart.bundle.min.js"> </script>
  <script src="assets/js/Chart.Financial.js"> </script>
 
  <!-- Page Specific Scripts Finish -->

  <!-- Weeducate core JavaScript -->
  <script src="assets/js/framework.js"></script>
    <!-- Page Specific Scripts Start -->
  <script src="assets/js/datatables.min.js"> </script>
  <script src="assets/js/data-tables.js"> </script>


  <!-- Settings -->
  <script src="assets/js/settings.js"></script>

</body>

</html>
